import socket

HOST = '127.0.0.1'  # The server's hostname or IP address
PORT = 65431        # The port used by the server


ClientTurn = False
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST,PORT))
    s.listen()
    conn, addr = s.accept()
    message = ''
    with conn:
        conn.sendall(b'hello world!')
        print("connected")
        while True :
            if ClientTurn :
                message = input()
                if message.__contains__('end') :
                    ClientTurn = False
                    conn.sendall(bytearray(message.encode()))
                else:
                    conn.sendall(bytearray(message.encode()))
            if not ClientTurn :
                data = conn.recv(1024)
                print(data)
                if data.decode() == 'end':
                    ClientTurn = True

